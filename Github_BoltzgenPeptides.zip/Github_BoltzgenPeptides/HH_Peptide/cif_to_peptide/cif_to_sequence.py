#!/usr/bin/env python3
"""
cif_to_sequence.py - Convert peptide/protein mmCIF files to one-letter sequences.

Usage:
    python cif_to_sequence.py design_077.cif                 # one file
    python cif_to_sequence.py my_cif_folder/                 # every .cif in a folder
    python cif_to_sequence.py my_cif_folder/ -o seqs         # writes seqs.fasta + seqs.csv

How it works:
  1. If the file has _entity_poly_seq (the declared polymer sequence), that is used.
  2. Otherwise the sequence is rebuilt from the modelled residues in _atom_site.
  Ligands, metals (e.g. FE), and water are ignored because only polymer chains are read.
"""
import argparse
import csv
import sys
from pathlib import Path

import gemmi


def one_letter(residue_names):
    """Turn ['HIS', 'ASN', ...] into 'HN...'. Unknown residues become 'X'."""
    return gemmi.one_letter_code(list(residue_names)).upper().replace("-", "X")


def sequences_from_cif(path):
    """Return a list of (chain_id, sequence, source) for every polymer chain."""
    structure = gemmi.read_structure(str(path))
    structure.setup_entities()  # works out which chains are polymer vs ligand
    results = []

    # Map each polymer entity to the chains that use it
    for entity in structure.entities:
        if entity.entity_type != gemmi.EntityType.Polymer:
            continue  # skips FE and any other non-polymer entity
        chains = ",".join(entity.subchains) or entity.name
        if entity.full_sequence:  # from _entity_poly_seq
            names = [gemmi.Entity.first_mon(m) for m in entity.full_sequence]
            results.append((chains, one_letter(names), "entity_poly_seq"))

    if not results:  # fallback: read the residues actually present in the model
        model = structure[0]
        for chain in model:
            polymer = chain.get_polymer()
            if len(polymer) == 0:
                continue
            names = [res.name for res in polymer]
            results.append((chain.name, one_letter(names), "atom_site"))
    return results


def main():
    parser = argparse.ArgumentParser(description="mmCIF -> one-letter sequence")
    parser.add_argument("input", help="a .cif file or a folder of .cif files")
    parser.add_argument("-o", "--out", default="sequences",
                        help="output prefix (default: sequences -> sequences.fasta/.csv)")
    args = parser.parse_args()

    inp = Path(args.input)
    files = sorted(inp.glob("*.cif")) + sorted(inp.glob("*.mmcif")) if inp.is_dir() else [inp]
    if not files:
        sys.exit(f"No .cif files found in {inp}")

    rows = []
    for f in files:
        try:
            for chain, seq, source in sequences_from_cif(f):
                rows.append({"file": f.stem, "chain": chain, "length": len(seq),
                             "sequence": seq, "source": source})
        except Exception as e:  # keep going if one file is broken
            print(f"WARNING: could not read {f}: {e}", file=sys.stderr)

    with open(f"{args.out}.fasta", "w") as fa:
        for r in rows:
            fa.write(f">{r['file']}_{r['chain']} length={r['length']}\n{r['sequence']}\n")
    with open(f"{args.out}.csv", "w", newline="") as fc:
        writer = csv.DictWriter(fc, fieldnames=["file", "chain", "length", "sequence", "source"])
        writer.writeheader()
        writer.writerows(rows)

    for r in rows:
        print(f"{r['file']}\t{r['chain']}\t{r['sequence']}")
    print(f"\nWrote {len(rows)} sequence(s) to {args.out}.fasta and {args.out}.csv")


if __name__ == "__main__":
    main()
